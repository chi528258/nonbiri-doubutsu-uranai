【のんびり動物占い】

GitHub Pagesにアップロードするファイル：
- index.html
- style.css
- script.js
- images/ フォルダ（中の6枚のjpgも必要）

フォルダ構成：
nonbiri_doubutsu_uranai/
  index.html
  style.css
  script.js
  images/
    capybara.jpg
    sloth.jpg
    panda.jpg
    koala.jpg
    otter.jpg
    shoebill.jpg

index.htmlをGitHub Pagesで公開すればサイトとして動きます。
